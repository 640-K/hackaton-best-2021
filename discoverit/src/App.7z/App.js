import React, {useState,useEffect} from "react";
import './App.css';
import { BrowserRouter as Router, Routes, Route} from "react-router-dom";

const App = () =>{
    let a = [
        {
            id: 0,
            name: "Church",
            link: "https://upload.wikimedia.org/wikipedia/commons/5/53/Lviv_Bernardine_monastery.jpg",
        },
        {
            id: 1,
            name: "City Hall",
            link: "https://lviv.travel/image/news/99/78/99783d62a5876cfa44b201c791496b4f0e379957_1581667807.jpeg?crop=3840%2C2066%2C0%2C47",

        },
        {
            id: 2,
            name: "Tower",
            link: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRWyU204P3MtPy_APPpkjy3aDlngzuPo7mlmJMgFRmCPPN5VWmqRhrAkQlRgj64kC38KaU&usqp=CAU",
        },
        {
            id: 3,
            name: "Museum",
            link: "https://api.time.com/wp-content/uploads/2019/09/british-museum-london-exterior.jpg",
        }
    ];
    let[items, setItems] = useState(a);
    
    return (    
    <div className="App">
        <header className="App-header">
            {items ? <Start items={items} setItems={setItems} />:<Loading />}
        </header>
    </div>
    );
}



function Loading(){
    return(
        <div className="spinner-border text-primary" role="status">
            <span className="sr-only"></span>
        </div>
    );
}



function Start({items,setItems}){
   
    let index = Math.floor(Math.random()*items.length)
    let item = items[index];
    let[points, setPoints] = useState(100);
    let[bartimer, setBarTimer] = useState(0);

    console.log(items);

    return(
        <div styles={{"display": "column"}}>
            <img className="rounded img-responsive" src={item.link} width="500" height="600"/>
            <ListContainer items={items} index={index} points={points} setPoints={setPoints}/>
            <div>
                {points}
            </div>
            <Bar bartimer={bartimer} setBarTimer={setBarTimer}/>
        </div>
    );
}



function ListContainer({items,index,points,setPoints}) {
    return(
        <ul className="name-list">
            {
                items.map(((item,keyId) => (
                    <li key={keyId}>
                        {keyId == index
                            ? <OptionButton item={item} points={points} setPoints={setPoints} success={true}/>
                            : <OptionButton item={item} points={points} setPoints={setPoints} success={false}/>
                        }
                    </li>)))
            }
        </ul>
    );
}

function OptionButton({item,points,setPoints,success}){
    if(success){
        return(<button type="button" className="btn btn-dark" onClick={()=>setPoints(points + 200)}>{item.name}</button>);
    }else{
        return(<button type="button" className="btn btn-dark" onClick={()=>setPoints(points - 100 < 0 ? 0 : points-100)}>{item.name}</button>);
    }
}

function Bar({bartimer, setBarTimer}) {
    return(
        <div class="progress">
            <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style={{"width": "55%"}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
    );
}

export default App;
